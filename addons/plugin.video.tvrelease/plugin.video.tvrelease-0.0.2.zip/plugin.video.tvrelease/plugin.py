import xbmc, xbmcplugin, xbmcaddon, xbmcgui, xbmcvfs
import os
import re
import sys

from addon.common.net import Net
from addon.common.addon import Addon
from metahandler import metahandlers


addon_id = 'plugin.video.tvrelease'
addon = Addon(addon_id, sys.argv)
Addon = xbmcaddon.Addon(addon_id)


sys.path.append( os.path.join( addon.get_path(), 'resources', 'lib' ) )
net = Net()

dbg = False

try:
    import StorageServer
except:
    import storageserverdummy as StorageServer
cache = StorageServer.StorageServer(addon_id)


url = addon.queries.get('url', '')
name = addon.queries.get('name', '')
mode = addon.queries.get('mode', '')
season = addon.queries.get('season', '')
episode = addon.queries.get('episode', '')


menu = [
    ('http://tv-release.net/?cat=TV-480p', '[COLOR red][B]*HD*480p[/B][/COLOR]'),
    ('http://tv-release.net/?cat=TV-720p', '[COLOR red][B]*HD*720p[/B][/COLOR]'),
    ('http://tv-release.net/?cat=TV-Mp4', '[COLOR red][B]Mp4[/B][/COLOR]'),
    ('http://tv-release.net/?cat=TV-XviD', '[COLOR red][B]XviD[/B][/COLOR]'),
    ]


def MAIN( menu ):
    Transform()
    for (url, name) in menu:
        addon.add_directory({'mode': 'index', 'url': url},{'title': name})
        
                        


def INDEX(url):
    addon.log('Indexing Url: %s'% url)
    turl = url

    html = getHTML( url )
    r = re.search(r'current\'\>(\d+)\<', html, re.I)
    if r:
        total = re.search(r'\>(\d+)\<\/a\>\<\/span\>\<\/div\>', html)
        title = 'Page %s of %s Available' % ( r.group(1), total.group(1) )
        if int(r.group(1)) >5:
            addon.add_directory({'mode': 'home', 'url': url},{'title': '<<<Home>>>'},is_folder=False)
        addon.add_item({},{'title': title}, is_folder=False)

    
    l = re.findall(r'<a href=\'(http://tv-release.net/\d+\/.*?)\'', html, re.I)

    if l:
        totalitems = len(l)
        for url in l:
            name = cleanName(url)
            if re.search(r'[\ss\d+e\d+|\s\d+\s\d+\s\d+]', name, re.I): types = 'episode'
            else: types = 'tvshow'
            #infoLabel = getMeta( name, types )

            #properties = {}
            #episodes_unwatched = str(int(infoLabel['episode']) - infoLabel['playcount'])
            #properties['UnWatchedEpisodes'] = episodes_unwatched
            #properties['WatchedEpisodes'] = str(infoLabel['playcount'])
        
            addon.add_directory({'mode': 'resolve', 'url': url},{'title': name},total_items=totalitems,is_folder=False)       
   
    if r:
        cat = re.search(r'(cat\=.*?)$', turl)
        if cat:
            if '?s=' in url:
                nextp = url
            else:
                page = str(int(r.group(1))+1)
                nextp = 'http://tv-release.net/index.php?page=%s&%s' %( page, cat.group(1))
            addon.add_directory({'mode': 'index', 'url': nextp},{'title': '>>Next Page>>>'})

            if int(page) >2:
                page = str(int(r.group(1))-1)
                nextp = 'http://tv-release.net/index.php?page=%s&%s' %( page, cat.group(1))
                addon.add_directory({'mode': 'index', 'url': nextp},{'title': '<<<Previous Page<<'})

            
                
                


def cleanName(url):
    addon.log('CleanName: %s' % url)
    name = ''
    season = ''
    episode = ''
    title = ''
    year = ''
    month = ''
    day = ''

    name = url.rpartition('/')[2]

    r =re.split(r'\d+p', name)
    if r:
        name = r[0]
        r = re.search(r'(.*?)\ss(\d+)e(\d+)', name, re.I)

        if r:
            name = r.group(1)+', Season: %s Episode: %s' % ( r.group(2), r.group(3))
            return name

        if not r:
            r = re.search(r'(.*?)\s(\d+)\s(\d+)\s(\d+)\s', name, re.I)
            if r:
                name = r.group(1)+', Year: %s Month: %s Date: %s' % ( r.group(2), r.group(3), r.group(4))
                return name
            else:
                return name
            
            

def getMeta( name, types):
    addon.log('GetMeta: %s, %s' % ( name, types ))
    airdate = ''
    imdb = ''
    season = ''
    episode = ''
    tvdb_id = ''
    
    metaget = metahandlers.MetaData()

    r = re.search(r'(.*?),\sseason\:\s(\d+)\sepisode\:\s(\d+)$', name, re.I)
    if r:
        name = r.group(1)
        season = r.group(2)
        episode = r.group(3)

        meta = metaget.get_meta('tvshow', name=name, year='')

        if meta['imdb_id'] == '':imdb = ''
        else:imdb = meta['imdb_id']
        if meta['tvdb_id'] == '': tvdb_id = ''
        else: tvdb_id = meta['tvdb_id']
        #if types == 'tvshow':return meta
        #infolabels = metaget.get_episode_meta(types, imdb_id=imdb, season=season, episode=episode
        if tvdb_id != '':
            infolabels = metaget._get_tvdb_episode_data(tvdb_id, season, episode)
            return infolabels
            

    else:
        addon.log('IMDB: %s'%(imdb))
        adon.log('TVDB_id: %s'%tvdb_id)
        adon.log(name)
        r = re.search(r'(.*?),\syear\:\s(\d+)\smonth\:\s(\d+)\sdate\:\s(\d+)$', name, re.I)
        if r:
            print 'after search'
            print r.groups()
            #airdate = r.group(2)+'-'+r.group(3)+'-'+r.group(4)
            

    #if types == 'episode':
    #    infolabels = metaget.get_episode_meta(types, imdb_id=imdb, season=season, episode=episode, air_date=airdate)
    #    print infolabels
        
    
   #infolabels = metaget.get_meta(types, name=name, imdb_id=imdb, year='')

    #if infolabels == '':
    #    infolabels['title'] = name
    #    infolabels['cover_url'] = ''
    #    infolabels['backdrop_url'] = ''
        
    
    #return infolabels


def RESOLVE(url):
    addon.log('RESOLVE: %s' % url)
    sources = []
    
    html = getHTML( url )
    import urlresolver
    for links in re.finditer(r'\'\>(http.*?)\<', html, re.I):
        hoster = re.search(r'\/\/(.*?)\/', re.sub(r'www\.', '',links.group(1))).group(1)
        hostedMedia = urlresolver.HostedMediaFile(url=links.group(1), title=hoster)
        sources.append(hostedMedia)

    source = urlresolver.choose_source(sources)
    if source:
        stream_url=source.resolve()
        playStreamUrl(stream_url)
    else: return

    
def playStreamUrl(stream_url):
    listitem = xbmcgui.ListItem(path=str(stream_url), iconImage='', thumbnailImage='')
    listitem.setProperty('IsPlayable', 'true')
    listitem.setPath(str(stream_url))
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem)
    return True


def Transform():
    if addon.get_setting('transform') == 'true':
        return
    if xbmcvfs.exists(xbmc.translatePath('special://masterprofile/sources.xml')):
        with open(xbmc.translatePath(os.path.join( addon.get_path(), 'resources', 'sourcesapp.xml'))) as f:
            sourcesapp = f.read()
            f.close()
        with open(xbmc.translatePath('special://masterprofile/sources.xml'), 'r+') as f:
            my_file = f.read()
            if re.search(r'http://transform.mega-tron.tv/', my_file):
                addon.log('Transform Source Found in sources.xml, Not adding.')
                return
            addon.log('Adding Transform source in sources.xml')
            my_file = re.split(r'</files>\n</sources>\n', my_file)
            my_file = my_file[0]+sourcesapp
            f.seek(0)
            f.truncate()
            f.write(my_file)
            f.close()
            Addon.setSetting(id='transform', value='true')
            

    else:
        xbmcvfs.copy(xbmc.translatePath(os.path.join( addon.get_path(), 'resources', 'sources.xml')),
                       xbmc.translatePath('special://masterprofile/sources.xml'))
        Addon.setSetting(id='transform', value='true')
                       
        

def getHTML( url ):
    headers = {'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
               'Accept-Encoding': 'gzip, deflate, sdch',
               'Accept-Language': 'en-GB,en-US;q=0.8,en;q=0.6', 'Host': 'tv-release.net',
               'Cache-Control': 'no-cache', 'Connection': 'keep-alive', 'DNT': '1',
               'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/40.0.2214.94 Safari/537.36'}

    html = net.http_GET(url, headers).content

    return html

if mode== 'main':
    MAIN( menu )
elif mode == 'index':
    INDEX(url)
elif mode == 'resolve':
    RESOLVE(url)











xbmcplugin.endOfDirectory(int(sys.argv[1]))
