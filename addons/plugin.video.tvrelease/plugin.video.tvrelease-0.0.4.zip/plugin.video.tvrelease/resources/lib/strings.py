def variables():
    season = ''
    episode = ''
    year = ''
    month = ''
    day = ''
    date = ''
    airdate = ''
    imbd = ''
    tvdb_id = ''
    return
